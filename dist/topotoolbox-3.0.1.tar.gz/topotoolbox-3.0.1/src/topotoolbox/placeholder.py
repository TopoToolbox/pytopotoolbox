def example(input):
    return str(input) + " example"
