import topotoolbox

print(dir(topotoolbox))
print(topotoolbox.example("test"))